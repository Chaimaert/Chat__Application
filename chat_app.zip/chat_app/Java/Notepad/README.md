# Notepad

**A simple Java Notepad using Java Swing**

### Introduction

In our university, There was a course called **"Object Oriented Programming"**. In this course, we had to build a basic project based on Java language. Then I made this "Notepad" text editor using the Java Swing framework. This is a simple text editor where you can write your content, save the file and some other extra features. Our faculty members organised a **CSE Project Show** where all the students have to show there projects and in this project show, I got the **Championship!** between all of the students in the categaory of "Object Oriented Programming".


### Features

- New File
- Save
- Save As
- Open a file
- Undo & Redo
- Cut, Copy & Paste
- Find and Replace
- Font
- Font Colors
- Word Wrap


### Platforms Supported

* Windows
* Mac OS

