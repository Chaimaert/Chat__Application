
# Messenger

**A simple Java Multi User Chat application using Java Socket Programming

### Introduction

In our university, There was a course called **"Advanced Object Oriented Programming Laboratory"**. In this course, we had to build a project based on Java Socket Programming. Using multitread is one of the biggest part of that project. The language was pre-defined and that is JavaFx. That time I made this multi user chat application called "Messenger". For the font-end part, I used JavaFx scene builder. Multiple client can chat with one another under the same network.


### Features

- Login / Registration
- Personal Profile
- User can update his/her profile
- Upload profile picture
- Sticky design
- Multithreading
- Sending messages


### Platforms Supported

* Windows
* Mac OS

